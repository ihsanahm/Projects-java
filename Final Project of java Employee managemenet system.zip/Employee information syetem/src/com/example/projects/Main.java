package com.example.projects;

public class Main {

    public static void main(String[] args) {
        DBconnection.connector();
    }

    public static class UpdateEmployee {
    }
}
